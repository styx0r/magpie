conf_data <- read.table("boxplot.config", sep = " ")
input_data <- as.data.frame(t(conf_data[,2]))
colnames(input_data) <- conf_data[,1]


box1 <- rnorm(n = input_data$n1, mean = input_data$mean1, sd = input_data$sd1)
box2 <- rnorm(n = input_data$n2, mean = input_data$mean2, sd = input_data$sd2)

box_data <- data.frame(value = box1, id = 1)
box_data <- rbind(box_data, data.frame(value = box2, id = 2))

png("boxplot.png")
boxplot(value ~ id, data = box_data)
dev.off()

for(l in 1:nrow(box_data)){
  write(paste(colnames(box_data), box_data[l,], collapse = ","), file = "boxplot.data", append = T)
}
