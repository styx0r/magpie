#!/bin/bash
Rscript generateBoxPlots.R
Rscript generateStackPlots.R
