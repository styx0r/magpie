conf_data <- read.table("stackedplot.config", sep = " ")
input_data <- as.data.frame(t(conf_data[,2]))
colnames(input_data) <- conf_data[,1]

spd <- data.frame() # stacked plot data
for(i in 1:conf_data$V2[conf_data$V1 == "clonesSTEPS"])
  spd <- rbind(spd, data.frame(value = as.integer(rnorm(n = conf_data$V2[conf_data$V1 == "clonesNR"], mean = conf_data$V2[conf_data$V1 == "cloneMEAN"], sd = conf_data$V2[conf_data$V1 == "cloneSIGMA"])),
                               id = factor(1:conf_data$V2[conf_data$V1 == "clonesNR"]),
                               time = i))

spd$value[spd$value < 0] <- 0

require(ggplot2)

png("stackedplot.png")
ggplot(spd, aes(x = time, y = value, group = id, fill = id)) +  geom_area(position = "fill")
dev.off()

for(l in 1:nrow(spd)){
  write(paste(colnames(spd), spd[l,], collapse = ","), file = "stackedplot.data", append = T)
}
