#!/bin/bash
Rscript generateBoxPlots.R
