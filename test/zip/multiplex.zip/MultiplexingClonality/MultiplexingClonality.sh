#!/bin/bash
Rscript BC_stuff.R
