#!/bin/bash
Rscript sleep.R
