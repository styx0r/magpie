import urllib2
import sys

class ConfigFile:
    def __init__(self, cfile):
        self.file = cfile
        self.params = {}
        self.parse_config()

    def parse_config(self):
        """Parse config file"""
        with open(self.file, 'r') as f:
            for line in [l for l in f.readlines() if not (l.startswith('#') or len(l.strip())==0)]:
                param, value = line.strip().split(' ')
                self.params[param] = str(value)


### Read in config

cfg = ConfigFile('default.config')

BASE_URL = "http://projects.biotec.tu-dresden.de/plip-rest/pdb"
query_url = '/'.join([BASE_URL, cfg.params['pdbid']])

try:
    response = urllib2.urlopen(query_url).read()
except urllib2.HTTPError:
    sys.stderr.write('Error: No result found for query PDB ID %s' % cfg.params['pdbid'])
    sys.exit(1)
with open('%s.%s' % (cfg.params['pdbid'], cfg.params['format']), 'w') as f:
    f.write(response)
print 'Successfully retrieved %s file for PDB ID %s from PLIP REST service.' % (cfg.params['format'], cfg.params['pdbid'])
