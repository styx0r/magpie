#!/bin/bash
Rscript analysis.R

