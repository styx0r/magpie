####################################################Measures#############################################

#SpeciesRichness#
Measures.SpeciesRichness <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, function(e){sum(e > 0)}) / nrow(.ccMatrix@data)
}

#Jackknife#
Measures.Jackknife <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, FUN = function(x){ 
    n = sum(x) 
    if(n == 0) return(0)
    k = sum(x == 1) 
    n + ((n-1)/n)^k })
}

#Chao#
Measures.Chao <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, FUN = function(x){
    So = sum(x) #S observed
    f1 = sum( x == 1 ) #number of singletons sampled
    f2 = sum( x == 2 ) #number of doublets sampled
    if(f2 > 0)
      So + (f1^2 / f2)
    else
      So
  })
}

#Relative Number of Clones#
Measures.RNoC <- function(.ccMatrix){
  colSums(.ccMatrix@data > 0) / nrct
}

#Clone Number Changes#
Measures.CNC <- function(.speciesRichness){
  .out <- -.speciesRichness@data
  .out[2:length(.speciesRichness@data)] <- abs( -.speciesRichness@data[2:length(.speciesRichness@data)] + .speciesRichness@data[1:(length(.speciesRichness@data)-1)])
  .out[1] <- NA
  return(.out)
}

#Simpson-Index#
Measures.SimpsonIndex <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN=2, FUN = function(c){
    1 - sum(c * (c - 1) / (sum(c) * (sum(c)-1)))
  })
}

#Shanon-Index#
Measures.ShannonIndex <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN=2, FUN = function(c){
    .p_i <- c / sum(c)
    .lp_i <- .p_i
    .lp_i[which(.lp_i != 0)] <- log(.lp_i[which(.lp_i != 0)])
    -sum(.p_i * .lp_i)/log(nrow(.ccMatrix@data))
  })
}

#Kwoka's Dominance Index#
Measures.KwokasDomincanceIndex <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, FUN = function(c){
    .tmp = sort(decreasing=TRUE, c)
    sum(.tmp[1:(length(.tmp)-1)] - .tmp[2:length(.tmp)])^2
  })
}

#Theil Index#
Measures.TheilIndex <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, FUN = function(c){
    .tmp = c/(mean(c))    
    .ltmp <- log(.tmp)
    #in case .ltmp is -Inf we set to 0
    .ltmp[which(is.infinite(.ltmp))] <- 0
    .tmp <- mean(.tmp * .ltmp)
  })
}

#Gini Index based on Lorenz curve#
Measures.GiniIndex <- function(.ccMatrix){
  apply(.ccMatrix@data, MARGIN = 2, FUN = function(c){
    A = 0
    sc = sort(c) #Sorted c
    for(i in 1:length(c)){
      pe = (sum(c) / length(c)) * i #Perfect equality
      individuals = sum(sc[1:i])
      A = A + pe - individuals
    }
    2 * A
  })
}

#MaxIncrease of Clonesize#
Measures.MaxIncrease <- function(.ccMatrix){
  .out <- .ccMatrix@data
  .out[,1] <- NA
  for(.c in 2:ncol(.out)) .out[which(.ccMatrix@data[,.c] < 10),.c] <- NA
  .out <- atan(((.ccMatrix@data[, 2:ncol(.ccMatrix@data)] - .ccMatrix@data[, 1:(ncol(.ccMatrix@data)-1)])/interval))
  #.out <- .ccMatrix@data[,2:ncol(.ccMatrix@data)] / .ccMatrix@data[, 1:(ncol(.ccMatrix@data) - 1)]
  .out <- apply(.out, MARGIN = 2, FUN = function(c){
    max(c, na.rm = TRUE)
  })
  c(NA, .out)
}

#Sum of Angles
Measures.SumAngle <- function(.ccMatrix){
  .out <- .ccMatrix@data
  .out[,1] <- NA
  for(.c in 2:ncol(.out)) .out[which(.ccMatrix@data[,.c] < 10),.c] <- NA
  .out <- atan(((.ccMatrix@data[, 2:ncol(.ccMatrix@data)] - .ccMatrix@data[, 1:(ncol(.ccMatrix@data)-1)])/interval))
  #.out <- .ccMatrix@data[,2:ncol(.ccMatrix@data)] / .ccMatrix@data[, 1:(ncol(.ccMatrix@data) - 1)]
  .out <- apply(.out, MARGIN = 2, FUN = function(c){
    sum(c, na.rm = TRUE)
  })
  c(NA, .out)
}

#Sum of negative Angles
Measures.SumNumberOfNegativeAngle <- function(.ccMatrix){
  .out <- .ccMatrix@data
  .out[,1] <- NA
  for(.c in 2:ncol(.out)) .out[which(.ccMatrix@data[,.c] < 10),.c] <- NA
  .out <- atan(((.ccMatrix@data[, 2:ncol(.ccMatrix@data)] - .ccMatrix@data[, 1:(ncol(.ccMatrix@data)-1)])/interval))
  #.out <- .ccMatrix@data[,2:ncol(.ccMatrix@data)] / .ccMatrix@data[, 1:(ncol(.ccMatrix@data) - 1)]
  .out <- apply(.out, MARGIN = 2, FUN = function(c){
    sum(c < 0, na.rm = TRUE)
  })
  c(NA, .out)
}

#MaxIncrease of Clonesize considering 2 follow ups#
Measures.MaxIncrease2F <- function(.ccMatrix){
  .out <- .ccMatrix@data
  .out[,1:2] <- NA
  for(.c in 3:ncol(.out)) .out[which(.ccMatrix@data[,.c] < 10), .c] <- NA
  .angles <- atan(((.ccMatrix@data[, 2:ncol(.ccMatrix@data)] - .ccMatrix@data[, 1:(ncol(.ccMatrix@data)-1)])/interval))
  .out <- .angles[, 2:ncol(.angles)] + .angles[, 1:(ncol(.angles) - 1)]
  .out[which(.out <= 0)] <- NA
  .out <- apply(.out, MARGIN = 2, FUN = function(c){
    max(c, na.rm = TRUE)
  })
  c(NA, NA, .out)
}

#MaxIncrease of Clonesize considering 2 follow ups#
Measures.ChangeAngle <- function(.ccMatrix){
  .out <- .ccMatrix@data
  .out[,1:2] <- NA
  for(.c in 3:ncol(.out)) .out[which(.ccMatrix@data[,.c] < 10), .c] <- NA
  .angles <- atan(((.ccMatrix@data[, 2:ncol(.ccMatrix@data)] - .ccMatrix@data[, 1:(ncol(.ccMatrix@data)-1)])/interval))
  .angles[which(.angles <= 0)] <- NA
  .out <- .angles[, 2:(ncol(.angles))] - .angles[, 1:(ncol(.angles) - 1)]
  .out <- apply(.out, MARGIN = 2, FUN = function(c){
    max(c, na.rm = TRUE)
  })
  .out[which(is.infinite(.out) | .out < 0)] <- 0
  c(NA, NA, .out)
}

#Normalisation of the measures#
Measures.Normalize <- function(.measure){
  .tmp <- .measure@data # - min(.measure@data)
  .max = max(.tmp[!is.na(.tmp)])
  if(.max < 0) .max <- min(.tmp[!is.na(.tmp)])
  if(.max != 0) .tmp[!is.na(.tmp)] <- .tmp[!is.na(.tmp)] / .max
  else .tmp <- rep(1, length(.tmp))
  return(.tmp)
}


###########################################################################################