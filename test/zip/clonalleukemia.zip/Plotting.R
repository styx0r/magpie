##############################Plotting functions#####################################

plot.mosaic <- function(.ccMatrix, xTitle = "Timepoints", yTitle = "Clones"){
  mosaicplot(t(.ccMatrix@data), 
             col = rainbow(nrow(ClonalContribution.ccMatrix@data)), 
             main = "ClonalContribution", 
             ylab = "Clones", 
             xlab = "Timepoints",
             las = 1 )
}

#Plotting function for stacked plotting of clones
plot.stacked <- function(.ccMatrix, main = "plot title"){
  .plot_values <- c()
  .plot_time <- c()
  .plot_clone <- c()
  for(i in 1:nrow(.ccMatrix@data)){
    .plot_values <- c(.plot_values, .ccMatrix@data[i,])
    .plot_clone <- c(.plot_clone, rep(i, ncol(.ccMatrix@data)))
  }
  .plot_time <- as.numeric(gsub("t ", "", colnames(.ccMatrix@data)))
  .plot_matrix <- cbind(.plot_time, .plot_clone, .plot_values)
  rownames(.plot_matrix) = c()
  .plot_df <- as.data.frame(.plot_matrix)
  colnames(.plot_df) <- c("Timestep", "Clone", "CloneSize")
  .plot_df$Timestep <- as.numeric(.plot_df$Timestep)
  .plot_df$RelativeSize <- as.numeric(.plot_df$CloneSize)
  .plot_df$Clone <- as.factor(.plot_df$Clone)
  print(ggplot(.plot_df, aes(x=Timestep, y=RelativeSize, fill=Clone)) +
          geom_area(colour="black", size=.2, alpha=.6) +
          ggtitle(ifelse(nrcc > 0, paste("Start of Cancer: ", cancer_ts[1]), "Without Cancer")) +
          scale_fill_manual(values = c(rainbow(nrct), rep("#000000", nrcc))) +
          ggtitle(label = main) +
          ylab("Absolute Size") +
          xlab("Time") +
          ggTheme)
}

#Plotting function for stacked plotting of clones
plot.stacked_relative <- function(.ccMatrix, main = "plot title"){
  .plot_values <- c()
  .plot_time <- c()
  .plot_clone <- c()
  for(.c in 1:ncol(.ccMatrix@data)) .ccMatrix@data[,.c] <- .ccMatrix@data[, .c] / sum(.ccMatrix@data[, .c])
  for(i in 1:nrow(.ccMatrix@data)){
    .plot_values <- c(.plot_values, .ccMatrix@data[i,])
    .plot_clone <- c(.plot_clone, rep(i, ncol(.ccMatrix@data)))
  }
  .plot_time <- as.numeric(gsub("t ", "", colnames(.ccMatrix@data)))
  .plot_matrix <- cbind(.plot_time, .plot_clone, .plot_values)
  rownames(.plot_matrix) = c()
  .plot_df <- as.data.frame(.plot_matrix)
  colnames(.plot_df) <- c("Timestep", "Clone", "RelativeSize")
  .plot_df$Timestep <- as.numeric(.plot_df$Timestep)
  .plot_df$RelativeSize <- as.numeric(.plot_df$RelativeSize)
  .plot_df$Clone <- as.factor(.plot_df$Clone)
  
#   .timepoints <- min(.plot_df$Timestep[which(is.na(.plot_df$RelativeSize))])
#   .plot_df$RelativeSize[which(is.na(.plot_df$RelativeSize))] <- 0
#   .plot_df$RelativeSize[which(.plot_df$Timestep >= .timepoints & .plot_df$Clone == 5)] <- 1
#   
  print(ggplot(.plot_df, aes(x=Timestep, y=RelativeSize, fill=Clone)) +
          geom_area(colour="black", size=.2, alpha=.6) +
          ggtitle(ifelse(nrcc > 0, paste("Start of Cancer: ", cancer_ts[1]), "Without Cancer")) +
          scale_fill_manual(values = c(rainbow(nrct), rep("#000000", nrcc))) +
          ggtitle(label = main) +
          ylab("Relative Size") +
          xlab("Time") +
          ggTheme)
}

Measures.Plot.Normalized <- function(.measure, .name, .timeSeries){
  #Creating the data.frame for the qplot/ggplot2 function
  pMatrix = as.matrix(.measure@normalized) #plotting Matrix
  pMatrix = cbind(pMatrix, 
                  .timeSeries@series[(length(.timeSeries@series) - length(.measure@normalized) + 1):(length(.timeSeries@series))])
  colnames(pMatrix) = c(.name, "Timesteps")
  pDataFrame = as.data.frame(pMatrix) #Data Frame representation
  p = ggplot(aes_string(x = "Timesteps", y = .name), data = pDataFrame, xlab = "", ylab = "")
  p + geom_point(col = "red", size = 5) +
    geom_line(size = 1, col = "darkblue") +
    scale_x_discrete() +
    scale_y_continuous() +
    ggtitle(paste("Normalized:", .name))
  #theme(plot.title = element_text(element_text(lineheight=.8, face="bold")))
}

Measures.Plot.UnNormalized <- function(.measure, .name, .timeSeries){
  #Creating the data.frame for the qplot/ggplot2 function
  pMatrix = as.matrix(.measure@data) #plotting Matrix
  pMatrix = cbind(pMatrix, 
                  .timeSeries@series[(length(.timeSeries@series) - length(.measure@data) + 1):(length(.timeSeries@series))])
  colnames(pMatrix) = c(.name, "Timesteps")
  pDataFrame = as.data.frame(pMatrix) #Data Frame representation
  p = ggplot(aes_string(x = "Timesteps", y = .name), data = pDataFrame, xlab = "", ylab = "")
  p + geom_point(col = "red", size = 5) +
    geom_line(size = 1, col = "darkblue") +
    scale_x_discrete() +
    scale_y_continuous() +
    ggtitle(paste("Unnormalized:", .name))
  #theme(plot.title = element_text(element_text(lineheight=.8, face="bold")))
}

#Plotting normalised measures in one plot#
Measures.Plot.NGroup <- function(.measures, .names, .timeSeries){
  #Creating the data.frame for the qplot/ggplot2 function
  pMatrix <- matrix(nrow=length(.timeSeries@series) * length(.measures), ncol = 3, data=NA)
  pMatrix[,1] <- rep(.timeSeries@series, length(.names))
  for(i in 1:length(names)){
    pMatrix[((i-1) * length(.timeSeries@series - .timeSeries@series) + 1):(i*length(.timeSeries@series)),2] = .names[i]
    pMatrix[((i-1) * length(.timeSeries@series - .timeSeries@series) + 1 + (length(.timeSeries@series) - length(.measures[[i]]@normalized))):(i*length(.timeSeries@series)),3] =
      .measures[[i]]@normalized
  }
  colnames(pMatrix) <- c("Timesteps", "Measures", "Values")
  pDataFrame = as.data.frame(pMatrix, stringsAsFactors=FALSE) #Data Frame representation
  pDataFrame[,3] = as.numeric(pDataFrame[,3])
  pDataFrame[,1] = as.numeric(pDataFrame[,1])
  p = ggplot(data = pDataFrame, aes(x = Timesteps, y = Values, colour = Measures), xlab = "", ylab = "")
  p + geom_line(size = 1) + 
    scale_x_discrete() +
    scale_y_continuous() +
    ggtitle("Normalized Comparison")
  #theme(plot.title = element_text(element_text(lineheight=.8, face="bold")))
}


#Plotting of histograms of certain timepoints#
plot_clone_histogram <- function(.ccMatrix, .t){
  .p_data <- as.data.frame(.ccMatrix@data[, .t])
  colnames(.p_data) <- as.character(.t-1)
  .p_data$clone <- factor(gsub("c ", "", rownames(.p_data)), levels = gsub("c ", "", rownames(.p_data)))
  .gg_data <- melt(.p_data, id.vars = "clone")
  colnames(.gg_data) <- c("clone","Day", "CloneSize")
  ggplot(.gg_data, aes(Day, CloneSize, fill=clone)) +
    geom_bar(stat="identity", position="dodge", colour="black", alpha=.6) +
    scale_fill_manual(values = c(rainbow(nrct), rep("#000000", nrcc)))
}


####################################################################################

###Plotting Andrea###
#p = ggplot(data = .andrea, aes_string(x = "Time", y = "CellNumber", colour = "Compartment"))
#print(p + geom_line(size = 1.3) + scale_y_log10(breaks = c(10,100,1000), name = "cell number") + scale_x_continuous(name = "time in h"))

