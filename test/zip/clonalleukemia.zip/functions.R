#Plotting function for stacked plotting of clones
plot.stacked_relative <- function(data, main = "", max.time = 750, cancer = F){
  colFun <- colorRampPalette(c("white", "darkblue"))
  colors <- colFun(nrow(data))
  if(cancer)
    colors[which(max(data[,ncol(data)]) == data[,ncol(data)])] <- "black"
  .plot_values <- c()
  .plot_time <- c()
  .plot_clone <- c()
  for(.c in 1:ncol(data)) data[,.c] <- data[, .c] / sum(data[, .c])
  .plot_df <- melt(data)
  colnames(.plot_df) <- c("Clone", "Timestep", "RelativeSize")
  .plot_df$Clone <- as.factor(gsub("c ", "", .plot_df$Clone))
  .plot_df$Timestep <- as.numeric(gsub("t ", "", .plot_df$Timestep))
  for(i in length(unique(.plot_df$Clone)):1){ .plot_df$Clone <- relevel(.plot_df$Clone, ref = as.character(i)) }
  .plot_df$Timestep <- .plot_df$Timestep/30
  ggplot(.plot_df, aes(x=Timestep, y=RelativeSize, fill=Clone)) +
    geom_area(colour="black", size=.2, alpha=.6) +
    scale_fill_manual(values = colors, guide = guide_legend(reverse = T)) +
    ggtitle(label = main) +
    theme(
      axis.title.y = element_text(vjust = 0.5, angle = 90, face = "bold",
                                  size = 14),
      axis.title.x = element_text(vjust = 0.5, angle = 0, face = "bold",
                                  size = 14),
      title = element_text(face = "bold", size = 18)) +
    xlim(c(0, max(.plot_df$Timestep) + 0.5))
}

recalcMRCEs <- function(data){
  mRCEs <- lapply(data, function(e){
    #   suppRates <- e$clonalCourse[,2:ncol(e$clonalCourse)] - e$clonalCourse[, 1:(ncol(e$clonalCourse)-1)] ####
    #   suppRates <- t(t(suppRates) / abs(apply((suppRates - abs(suppRates)) / 2, MARGIN = 2, FUN = sum)))
    #   #Adustement of the suppRates according to the size of a clone
    #   for(.c in 1:ncol(suppRates)){
    #     .sum <- sum((suppRates/e$clonalCourse[, .c+1])[which(suppRates[,.c] > 0),.c])
    #     .sumN <- abs(sum((suppRates/e$clonalCourse[, .c+1])[which(suppRates[,.c] < 0),.c]))
    #     suppRates[which(suppRates[,.c] > 0), .c] =
    #       (suppRates/e$clonalCourse[, .c+1])[which(suppRates[,.c] > 0), .c] / .sum # TODO: Why is there a problem when we leave out the division of .sum???
    #     suppRates[which(suppRates[,.c] < 0), .c] =
    #       (suppRates/e$clonalCourse[, .c+1])[which(suppRates[,.c] < 0), .c] / .sumN # TODO: Why is there a problem when we leave out the division of .sum???
    #   }
    #Equal to:
    #Calculation increasment / decreasement of a clone of two consecutive points in time
    suppRate <- e$clonalCourse[,2:ncol(e$clonalCourse)] - e$clonalCourse[, 1:(ncol(e$clonalCourse)-1)]
    #Normalize according to suppressed clones
    suppRate <- t(t(suppRate) / abs(apply(suppRate, MARGIN = 2, FUN = function(e){sum(e[e < 0], na.rm = T)})))
    #Normalize according to size of the clones (or in other words according to one cell)
    suppRate <- suppRate / e$clonalCourse[, 2:(ncol(e$clonalCourse))]
    #Normalize positive to one and negative to -1
    posSums <- apply(suppRate, MARGIN = 2, FUN = function(e){sum(e[e > 0], na.rm = T)})
    negSums <- abs(apply(suppRate, MARGIN = 2, FUN = function(e){sum(e[e < 0], na.rm = T)}))
    for(.c in 1:ncol(suppRate)){
      suppRate[suppRate[, .c] > 0 & !is.na(suppRate[, .c]),.c] <- suppRate[suppRate[, .c] > 0 & !is.na(suppRate[, .c]),.c] / posSums[.c]
      suppRate[suppRate[, .c] < 0 & !is.na(suppRate[, .c]),.c] <- suppRate[suppRate[, .c] < 0 & !is.na(suppRate[, .c]),.c] / negSums[.c]
    }
    # Additional stuff if the cancer is trivial or if a clone is 0 set mRCE accordingly
    for(.c in 1:ncol(suppRate)){
      #if(sum(is.na(suppRate[,.c])) >= nrow(suppRate)/4){
      #if(sum(e$clonalCourse[,.c+1]) > 1500 || sum(e$clonalCourse[,.c+1] != 0) < 2){
      if(sum(e$clonalCourse[,.c+1] != 0) < 2){
        #if(sum(e$clonalCourse[,2:ncol(e$clonalCourse)] - e$clonalCourse[, 1:(ncol(e$clonalCourse)-1)][,.c] < 0, na.rm = T) == 0){
        suppRate[e$clonalCourse[,(.c+1)] == max(e$clonalCourse[,(.c+1)]),.c] <- 1.0
        suppRate[e$clonalCourse[,(.c+1)] != max(e$clonalCourse[,(.c+1)]),.c] <- 0
      }
      else{
        #if(e$rCancer) suppRate[is.na(suppRate[,.c]),.c] <- 1
        #else suppRate[is.na(suppRate[,.c]),.c] <- 0
      }
    }
    
    e$mRCE <- suppRate
    
    # Additional rule: if all clones are lower than 5 percent of the one clone => pathological
    trivialCase <- apply(X = e$clonalCourse[, 2:ncol(e$clonalCourse)], MARGIN = 2, FUN = function(c){
      perc <- max(c)/100 * 5
      if(all(c[c != max(c)] < perc)){
        c[c != max(c)] <- 0
        c[c == max(c)] <- 1
      }
      else
        c[1:length(c)] <- 0
      return(c)
    })
    
    e$mRCE[,which(colSums(trivialCase) == 1)] <- trivialCase[,which(colSums(trivialCase) == 1)]
    return(e$mRCE)
    
  })
  for(i in 1:length(mRCEs)){data[[i]]$suppRates <- mRCEs[[i]]}
  data
}

# # Optionally lets consider the retrospectivety ####
calcRetro <- function(data, n = 3){
  for(l in 1:length(data)){
    .l <- data[[l]]
    tmp <- .l$suppRates
    tmp[1:length(tmp)] <- 0
    for(i in 1:n) tmp[, i:ncol(tmp)] <- tmp[, i:ncol(tmp)] + .l$suppRates[, 1:(ncol(tmp) - i + 1)]
    data[[l]]$suppRates <- tmp[,n:ncol(tmp)]/n
  }
  return(data)
}
#####

