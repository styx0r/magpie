##############################Library Setup################################################
library("ggplot2")
library("deSolve")
library("pracma")
library("reshape")
###########################################################################################

#####################################Source################################################

source("Objects.R")
source("Measures.R")

###########################################################################################

####################################Program Code###########################################

ClonalContribution.TimeSeries = new("TimeSeries",
                                    series = seq(stp, stp + ts),
                                    start = stp,
                                    end = stp + ts,
                                    tp = stp
)

ClonalContribution.ccMatrix = new("ccMatrix",
                                  data = matrix(nrow = nrct + nrcc, 
                                                ncol = 1,#length(ClonalContribution.TimeSeries@series),
                                                data = 0)
)
rownames(ClonalContribution.ccMatrix@data) <- lapply(seq(1:nrow(ClonalContribution.ccMatrix@data)), function(x) paste("c", x))
colnames(ClonalContribution.ccMatrix@data) <- lapply(seq(1:ncol(ClonalContribution.ccMatrix@data)), function(x) paste("t", x-1))
ClonalContribution.ccMatrix = initiate.ccMatrix(ClonalContribution.ccMatrix)


#creating all values for every single timestep
ClonalContribution.ccMatrix = calcTimeCourse(ClonalContribution.ccMatrix, ts)

colnames(ClonalContribution.ccMatrix@data) <- lapply(seq(1:ncol(ClonalContribution.ccMatrix@data)), function(x) paste("t", x-1))
  

#Plotting of the Clonal Contribution
#plot.mosaic(ClonalContribution.ccMatrix)
if(length(args) == 3) 
  pdf(paste(save_dir, "/plots/", seed, ".pdf", sep = ""), paper = "a4r")
#plot.stacked(ClonalContribution.ccMatrix)
if(length(args) == 3) 
  dev.off()

#Plotting of the Clonal Contribution with putting the cancer cells to one of the initial clones
if(nrcc > 0){
  ClonalContribution.ccMatrixMixed = new("ccMatrix", 
                                         data = ClonalContribution.ccMatrix@data[1:nrct,]
  )
  
  #Adding the cancer cell sizes to the different clones (important: they should have not size 0 at considered timepoint)
  CancerClone = 0
  for(.cc in 1:nrcc){
    .clone <- sample(nrct, size = 1, prob = ClonalContribution.ccMatrixMixed@data[,cancer_ts[.cc]])
    CancerClone = .clone
    ClonalContribution.ccMatrixMixed@data[.clone,] <- ClonalContribution.ccMatrixMixed@data[.clone,] + ClonalContribution.ccMatrix@data[nrct + .cc,]
  }
  
  if(length(args) == 3)
    pdf(paste(save_dir, "/plots/", seed, "_mixed.pdf", sep = ""), paper = "a4r")
  #plot.stacked(ClonalContribution.ccMatrixMixed)
  if(length(args) == 3)
    dev.off()
}

#Saving the relevant data into objects
if(length(args) == 3){
  save(ClonalContribution.ccMatrix, file = paste(save_dir, "/ccMatrix/", seed, "_ClonalContribution.ccMatrix", sep = ""))
  if(nrcc > 0){
    save(ClonalContribution.ccMatrixMixed, file = paste(save_dir, "/ccMatrix/", seed, "_ClonalContribution.ccMatrixMixed", sep = ""))
    save(CancerClone, file = paste(save_dir, "/CancerClone/", seed, "_CancerClone", sep = ""))
    save(cancer_ts, file = paste(save_dir, "/cancer_ts/", seed, "_cancer_ts", sep=""))
  }
  save(ClonalContribution.TimeSeries, file = paste(save_dir, "/TimeSeries/", seed, "_ClonalContribution.TimeSeries", sep = ""))
  save(clone_divisions, file = paste(save_dir, "/clone_divisions/", seed, "_clone_divisions", sep = ""))
}
