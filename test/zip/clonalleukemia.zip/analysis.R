require("methods")
source("functions.R") # some general function (includes the mRCE calculation)
config <- read.table("cc.config", stringsAsFactors = F)

######################### Preparing the data #########################

out <- list()

# PATH: running the pathological simulation (with initialisation of a cancer cell)
seed <<- as.numeric(config[config[,1] == "seed",2]) # defines the seed to make it reproducable
source("Configuration.R")

tsStop <<- as.numeric(config[config[,1] == "max_time_cancer_outgrowth",2]) # Defines the max time in case clonal outgrowth did not happen
max_tries <- as.numeric(config[config[,1] == "max_tries_cancer_outgrowth",2])
source("CC.R")
tries <- 1
while((ncol(ClonalContribution.ccMatrixMixed@data) - 1) >= 0.9*tsStop & tries <= max_tries){
  source("CC.R")
  tries <- tries + 1
}
tsStop <<- ncol(ClonalContribution.ccMatrixMixed@data) - 1 # stop at the same point in time when cancer simulation stopped

out[[1]] <- list()
out[[1]]$clonalCourse <- ClonalContribution.ccMatrixMixed@data[,seq(1, tsStop, 30)]
out[[1]]$clonalContribution <- ClonalContribution.ccMatrixMixed
out[[1]]$cancerClone <- CancerClone
if(tries > max_tries)
  out[[1]]$cancerClone <- "none"

# HEALTHY: running the same configuration, but without a cancer clone
seed <<- as.numeric(config[config[,1] == "seed",2])

source("ConfigurationWithoutCancer.R")
source("CC.R")

out[[2]] <- list()
out[[2]]$clonalCourse <- ClonalContribution.ccMatrix@data[,seq(1, tsStop, 30)]
out[[2]]$clonalContribution <- ClonalContribution.ccMatrix
out[[2]]$cancerClone <- CancerClone

if(config[config[,1] == "save_raw_data",2] == "true"){
  write.table(file = "time_course_cancer.txt", x = out[[1]]$clonalContribution@data, sep = ";")
  write.table(file = "time_course_normal.txt", x = out[[2]]$clonalContribution@data, sep = ";")
  write.table(file = "cancer_clone.txt", x = out[[1]]$cancerClone, row.names = F, col.names = F)
}

############################ Measure calculation #########################

# Calculating the mRCE values (based on definition in function.R)
data <- recalcMRCEs(out) 
fu <- list()
fu$heal <- data[[2]]
fu$path <- data[[1]]

mSize <- ncol(fu$path$clonalCourse)
measures <- as.data.frame(cbind(apply(fu$path$suppRates, MARGIN=2, FUN = function(r){max(r, na.rm =T)}), apply(fu$heal$suppRates, MARGIN=2, FUN = function(r){max(r, na.rm = T)})))
measures$time <- as.numeric(gsub("t ", "", rownames(measures)))
colnames(measures) <- c("Pathological", "Healthy", "Time")
measures <- do.call("rbind", apply(measures, MARGIN = 1, function(r){
  data.frame(time = r["Time"], 
             type = "mRCE",
             variable = c("Pathological", "Healthy"), 
             value = c(r["Pathological"], r["Healthy"]))
}))

# Calculate the classical indices
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[1]]$clonalContribution)))),
                                       type = "Species Richness",
                                       variable = "Pathological",
                                       value = 1-Measures.SpeciesRichness(out[[1]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[1]]$clonalContribution)))),
                                       type = "Simpson Index",
                                       variable = "Pathological",
                                       value = 1-Measures.SimpsonIndex(out[[1]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[1]]$clonalContribution)))),
                                       type = "Shannon Index",
                                       variable = "Pathological",
                                       value = 1-Measures.ShannonIndex(out[[1]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[1]]$clonalContribution))))[seq(1,tsStop,20)],
                                       type = "Largest Clone",
                                       variable = "Pathological",
                                       value = (apply(out[[1]]$clonalContribution@data, MARGIN = 2, max) / colSums(out[[1]]$clonalContribution@data))[seq(1,tsStop,20)]))

measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[2]]$clonalContribution)))),
                                       type = "Species Richness",
                                       variable = "Healthy",
                                       value = 1-Measures.SpeciesRichness(out[[2]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[2]]$clonalContribution)))),
                                       type = "Simpson Index",
                                       variable = "Healthy",
                                       value = 1-Measures.SimpsonIndex(out[[2]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[2]]$clonalContribution)))),
                                       type = "Shannon Index",
                                       variable = "Healthy",
                                       value = 1-Measures.ShannonIndex(out[[2]]$clonalContribution)))
measures <- rbind(measures, data.frame(time = as.numeric(gsub("t ", "", names(Measures.SpeciesRichness(out[[2]]$clonalContribution))))[seq(1,tsStop,20)],
                                       type = "Largest Clone",
                                       variable = "Healthy",
                                       value = (apply(out[[2]]$clonalContribution@data, MARGIN = 2, max) / colSums(out[[2]]$clonalContribution@data))[seq(1,tsStop,20)]))


############################ Plotting Section ###############################

require("ggplot2")
ggTheme <- theme_bw() + theme(
  axis.title.y = element_text(vjust = 0.5, angle = 90, face = "bold",
                              size = 16),
  axis.title.x = element_text(vjust = 0.5, angle = 0, face = "bold",
                              size = 16),
  axis.text = element_text(size = 14),
  title = element_text(face = "bold", size = 18))

# Clonal contributions
i <- mSize
png("clonal contribution healhty.png", width = 2048, height = 1536, res = 300)
plot.stacked_relative(fu$heal$clonalCourse[, 1:i], max.time = tsStop, cancer = F) + 
  ggTheme + 
  theme(legend.position = c(0.97,0.5169),
        legend.background = element_rect(fill=alpha('white', 0)),
        legend.text = element_text(size = 6),
        legend.title = element_text(size = 8),
        legend.key.size = unit(x = 0.4805, units = "cm")) +
  ylab("relative clonal size") +
  xlab("time [months]")
dev.off()

png("clonal contribution pathological.png", width = 2048, height = 1536, res = 300)
plot.stacked_relative(fu$path$clonalCourse[, 1:i], max.time = tsStop, cancer = T) + 
  ggTheme + 
  theme(legend.position = c(0.97,0.5169),
        legend.background = element_rect(fill=alpha('white', 0)),
        legend.text = element_text(size = 6),
        legend.title = element_text(size = 8),
        legend.key.size = unit(x = 0.4805, units = "cm")) +
  ylab("relative clonal size") +
  xlab("time [months]")
dev.off()


# Measures
colors <- c("orange",
            "dodgerblue",
            "firebrick",
            "forestgreen",
            "black")

png("measures healthy.png", width = 2048, height = 1536, res = 300)
ggplot(measures[measures$variable == "Healthy",], aes(time/30, value, colour = type)) + 
  geom_line(aes(linetype = type), size = 1.2, alpha = .8) +
  geom_point(aes(shape = type), size = 6, alpha = .6) +
  #geom_point(cancerClone, aes(time, size)) +
  scale_colour_manual(name = "Measure", values = colors) +
  scale_linetype_manual(name = "Measure", values=c(1,1,1,1,0)) +
  scale_shape_manual(name = "Measure", values=c(NA,NA,NA,NA,20)) +
  ylim(c(0,1)) +
  ggTheme +
  xlab(label = "time [months]") +
  theme(legend.position = c(0.145,0.8)) +
  guides(colour = guide_legend(title = "measure"), 
         linetype = guide_legend(title = "measure"),
         shape = guide_legend(title = "measure"))
dev.off()

png("measures pathological.png", width = 2048, height = 1536, res = 300)
ggplot(measures[measures$variable == "Pathological",], aes(time/30, value, colour = type)) + 
  geom_line(aes(linetype = type), size = 1.2, alpha = .8) +
  geom_point(aes(shape = type), size = 6, alpha = .6) +
  #geom_point(cancerClone, aes(time, size)) +
  scale_colour_manual(name = "Measure", values = colors) +
  scale_linetype_manual(name = "Measure", values=c(1,1,1,1,0)) +
  scale_shape_manual(name = "Measure", values=c(NA,NA,NA,NA,20)) +
  ylim(c(0,1)) +
  ggTheme +
  xlab(label = "time [months]") +
  theme(legend.position = c(0.145,0.8)) +
  guides(colour = guide_legend(title = "measure"), 
         linetype = guide_legend(title = "measure"),
         shape = guide_legend(title = "measure"))
dev.off()




