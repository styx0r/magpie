################Definition of Objects and their functions##################################


#Class for the TimeSeries
setClass("TimeSeries",
         representation(series = "numeric",
                        start = "numeric",
                        end = "numeric",
                        tp = "numeric" #timepoint
         )
)

#Class for the data, which holds the clonal contribution over time
#col(cell) represents the timepoint and row(cell) the corresponding number
#of clones
setClass("ccMatrix",
         representation(data = "matrix"))

#The initialisation function for the ccMatrix object
initiate.ccMatrix <- function(object){
  if(initdist == "equal"){
    object@data[,1] = equc 
  }
  else if(initdist == "defined"){
    object@data[,1] = initCloneSizes
  }
  else{ #the case we consider a random distribution
    object@data[,1] = as.integer(runif(min=minc, max=maxc, length(object@data[,1])))
  }
  
  #Sort according to the size of the initial populations
  #object@data[,1] <- sort(object@data[,1], decreasing=TRUE)
  
  #Here we initialize the matrices for the nDistributionFixed configuration
  if(prolif == "nDistributedFixed"){
    prolifDistributionFixedValues <<- rnorm(n = nrct + nrcc, mean=prolifnDistributedMean, sd=prolifnDistributedSigma)
    prolifDistributionFixedValues[which(prolifDistributionFixedValues < 0)] <<- prolifnDistributedMean
  }
  if(death == "nDistributedFixed"){
    deathDistributionFixedValues <<- rnorm(n = nrct + nrcc, mean=deathnDistributedMean, sd=deathnDistributedSigma)
    deathDistributionFixedValues[which(deathDistributionFixedValues < 0)] <<- deathnDistributedMean
  }
  
  #Cancer cells are set to zero initially
  if(nrcc > 0)
    object@data[(nrct + 1):(nrcc + nrct)] = 0
  
  if(ageing == TRUE){
    #if ageing is activated we create the aging matrix
    clone_divisions <<- matrix(nrow = ts + 1, ncol = nrcc + nrct, data = 0)
    clone_divisions[1,] <<- object@data[,1]
    #and a vector with the ageing effect according to the
    #age of the cancers
    ageingfunprolif <<- rep(1, ts + 1)
    ageingfundeath <<- rep(1, ts + 1)
    if(ageingprolif == TRUE)
      ageingfunprolif <<- ageingfunprolif - (ageingprolifa * (0:ts) + ageingprolifb)
    if(ageingdeath == TRUE)
      ageingfundeath <<- ageingfundeath + (ageingdeatha * (0:ts) + ageingdeathb)
    #normalization otherwise proliferation can exceed a doubling up
    #ageingfun <<- max(ageingfun)
  }
  
  #Initializing carying capacity for the compartments
  if(nrcomp > 1){
    prolifCC <<- rep(prolifCC, each = nrct + nrcc / nrcomp)
    deathCC <<- rep(deathCC, each = nrct  + nrcc/ nrcomp)
  }
  
  return(object) #return the object
}

#Class for calculating a measurement
setClass("Measurement",
         representation(data = "numeric",
                        normalized = "numeric")
)

#Function for the calculation of the change in the rates .d (f.e.: .d = (p - d(N/k)))
diff_rates <- function(.N){
  
  .p = rep(0, nrct + nrcc) #The calculated difference to the last value
  
  #Calculates the rates, depending on the method for proliferation
  switch(prolif,
         fixed = { .p = rep(prolifvf, nrct + nrcc) },
         nDistributed = { 
           .p = rnorm(n = nrct + nrcc, mean=prolifnDistributedMean, sd=prolifnDistributedSigma) 
           .p[.p < 0] = 0
         },
         eDistributed = { .p = runif(n = nrct + nrcc) },
         nDistributedFixed = { .p = prolifDistributionFixedValues },
         defined = { .p = prolifdefined }
  )
  
  #putting the rates for cancer cells
  if(nrcc > 0) .p[(nrct + 1):(nrct+nrcc)] = cancer_prolifvf[1:nrcc]
  
  #Distinguish with / without logistic function for proliferation
  if(prolifWithLF == TRUE){
    .dumping = 1 - .N/prolifCC
    .dumping[which(.dumping > 1)] <- 1
    .dumping[which(.dumping < 0)] <- 0
    .p = .p * .dumping
  }
  
  #Part for death calculation
  .d = rep(0, nrct + nrcc) #The calculated difference to the last value
  
  #Calculates the rates, depending on the method for death
  switch(death,
         fixed={ .d = rep(deathvf, nrct + nrcc) },      
         nDistributed={ 
           .d = rnorm(n = nrct + nrcc, mean=deathnDistributedMean, sd=deathnDistributedSigma) 
           .d[.d < 0] = 0
         },
         eDistributed={ .d = runif(n = nrct + nrcc) },
         nDistributedFixed = { .d = deathDistributionFixedValues }
  )
  
  #Putting the corresponding deathratios for the cancer cells
  if(nrcc > 0) .d[(nrct + 1):(nrct+nrcc)] = cancer_deathvf[1:nrcc]
  
  #Distinguish with / without logistic function for death
  if(deathWithLF == TRUE){
    .dumping = .N/deathCC
    if(.dumping > 1) .dumping = 1
    if(.dumping < 0) .dumping = 0    
    .d = .d * .dumping
  }
  
  .out <- list()
  .out$p = .p
  .out$d = .d
  return(.out)
  
}

#Calculates the n for the next timestep
calcTimeCourse <- function(.ccMatrix, .ts){
  
  if(fixed_step){
    .t <- 0
    while(TRUE){
      .t <- .t + 1
      .ac = ClonalContribution.TimeSeries@tp - ClonalContribution.TimeSeries@start + 1 #actual column
      print(paste("Timestep:", .t, "succesfully calculated. Clones left:", sum(.ccMatrix@data[,.ac] > 0)))

      #if we reached already the last timestep before, do nothing
      #if(.ac == 3000) return(.ccMatrix)
      
      #Calculating the diff rates for this step
      .cpc <- (nrct + nrcc)/nrcomp #cells per compartment
      .N <- c()
      for(.comp in 1:nrcomp)
        .N <- c(.N, rep(sum(.ccMatrix@data[((.comp-1)*.cpc + 1):(.comp * .cpc),.ac]), .cpc))
      
      .pd = diff_rates(.N)
      .diff = .pd$p - .pd$d
        
      #In the ageing approach the different columns of clone_divisions (ageing - columns) have to be considered#
      if(ageing == TRUE){
        if(dice == TRUE){
          #In the case if diceing we calculate first the actual number of cells for one clone which divide and which die / differentiate
          #We have to consider every single clone and division as its own
          #First adjust the rows for the clone_divisions table
          if(sum(clone_divisions[nrow(clone_divisions) - 1,]) > 0){
            clone_divisions <<- rbind(clone_divisions, matrix(nrow = nrow(clone_divisions), ncol = nrcc + nrct, data = 0))
            ageingfunprolif <<- rep(1, nrow(clone_divisions) + 1)
            ageingfundeath <<- rep(1, nrow(clone_divisions) + 1)
            ageingfundeath <<- ageingfundeath + (ageingdeatha * (0:nrow(clone_divisions)) + ageingdeathb)
            #print(clone_divisions)
          }
          for(.c in 1:ncol(clone_divisions)){
            .max <- which(clone_divisions[,.c] != 0)
            if(length(.max) == 0) next
            .max <- max(.max)
            .min <- min(which(clone_divisions[,.c] != 0))            
            for(.d in .max:.min){
              #If there is no clone, there is nothing to do
              if(clone_divisions[.d,.c] == 0) next
              #Dice for the proliferation
              .cprolif <- runif(clone_divisions[.d, .c])
              #Dice for the death / differentiation
              .cdeath <- runif(clone_divisions[.d, .c])
              #Calc the ID's for the potential proliferating cells
              .prolifids <- which(.cprolif < (ageingfunprolif[.d] * .pd$p[.c]))
              #Calc the ID's for the potential death cells
              .deathids <- which(.cdeath < (ageingfundeath[.d] * .pd$d[.c]))
              #calculate the intersection of prolif and death cells
              .intersect <- intersect(.prolifids, .deathids)
              #calculate the lengths
              .prolifids <- length(.prolifids) - length(.intersect)
              .deathids <- length(.deathids) - length(.intersect)
              .intersect <- length(.intersect)
              #Save all cells, which are not prolif and death or which do both
              clone_divisions[.d, .c] <<- clone_divisions[.d, .c] - .prolifids - .deathids - .intersect
              clone_divisions[.d + 1, .c] <<- clone_divisions[.d + 1, .c] + 2*.prolifids + .intersect
            }
          }
          if(mutation == TRUE){
             .tmp <- clone_divisions
             for(.c in 1:ncol(clone_divisions)){
               .max <- which(clone_divisions[,.c] != 0)
               if(length(.max) == 0) next
                 .max <- max(.max)
               .min <- min(which(clone_divisions[,.c] != 0))            
               for(.d in .max:.min){
                 for(.t in 1:nrct){
                   if(.t == .c || m_trans_prob[.c, .t] == 0) next
                   .nr_clones <- .tmp[.d, .c]
                   #If there is no clone, there is nothing to do
                   if(.nr_clones == 0) break
                   .nc <- length(which(runif(.nr_clones) < m_trans_prob[.c, .t]))
                   .tmp[.d, .c] <- .tmp[.d, .c] - .nc
                   clone_divisions[.d, .c] <<- clone_divisions[.d, .c] - .nc
                   clone_divisions[.d, .t] <<- clone_divisions[.d, .t] + .nc
                 }
               }
             }
          }
        }
        #Consideration without diceing
        else{
          print("Ageing without Diceing not possible, since small splits of cells in clone_divisions!")
          quit()
        }
        #Putting the sum of all rows of one column as the actual clone size
        #.ccMatrix@data[, .ac + 1] = apply(clone_divisions, MARGIN=2, FUN=sum)
        .ccMatrix@data <- cbind(.ccMatrix@data, apply(clone_divisions, MARGIN = 2, FUN = sum))
      }
      #Consideration without ageing
      else{
        #Calculating the absolute values for the considered timepoint, based on the proliferation rates .p and death rates .d
        #if dice is activated, we consider every single individual and dice according to the corresponding .diff value
        if(dice == TRUE){
          .ccMatrix@data <- cbind(.ccMatrix@data, .ccMatrix@data[, .ac])
          for(.r in 1:nrow(.ccMatrix@data)){
            .i = as.integer(.ccMatrix@data[.r, .ac]) #Individuals
            if(.i == 0) next
            else{
              .ccMatrix@data[.r, .ac + 1] <- .ccMatrix@data[.r, .ac + 1] - length(which(runif(.i) < .pd$d[.r]))
              .ccMatrix@data[.r, .ac + 1] <- .ccMatrix@data[.r, .ac + 1] + length(which(runif(.i) < .pd$p[.r]))
              if(mutation == TRUE){
                for(.t in 1:nrct){
                  if(.t == .r || m_trans_prob[.r, .t] == 0) next
                  .nc <- length(which(runif(as.integer(.ccMatrix@data[.r, .ac+1])) < m_trans_prob[.r, .t]))
                  .ccMatrix@data[.r, .ac + 1] <- .ccMatrix@data[.r, .ac + 1] - .nc
                  .ccMatrix@data[.t, .ac + 1] <- .ccMatrix@data[.t, .ac + 1] + .nc
                }
              }
            }
          }
        }
        else{
          for(.d in 1:length(.diff)) .diff[.d] <- rnorm(1, mean = .diff[.d], sd = noDiceNoise)
          .ccMatrix@data[, .ac + 1] = .ccMatrix@data[, .ac] + .ccMatrix@data[, .ac] * .diff #without diceing
        }
      }
      
      #If the number overcomes the maximum integer, set it to the max
      .ccMatrix@data[which(is.na(.ccMatrix@data[, .ac + 1])), .ac + 1] = .Machine$double.max.exp
      
      #If the considered timestep is in cancer_ts, we simulate the transplate
      if(nrcc > 0 && (.t %in% cancer_ts)){
        for(i in which(cancer_ts == .t)){
          .ccMatrix@data[nrct + i, .ac + 1] = cancer_sizes[i]
          if(ageing == TRUE){ #In that case we have to put it into the clonel_devisions
            clone_divisions[1, nrct + i] <<- cancer_sizes[i]
          }
        }
      }
      
      #If transplant is activated and the actual timestep is the first round of the next
      #cyclus, we transplant
      if(ClonalContribution.TimeSeries@tp != 0 && serial_transplant == TRUE && mod(ClonalContribution.TimeSeries@tp, serial_transplant_cyclus) == 0){
        .tmp = .ccMatrix@data[, .ac + 1]
        if(ageing == TRUE){
          .tmp_ageing = clone_divisions
          clone_divisions <<- clone_divisions * 0
        }
        .ccMatrix@data[, .ac + 1] <- .ccMatrix@data[, .ac + 1] * 0
        .cells_to_transplant = serial_noftc
        if(sum(.tmp) < serial_noftc) .cells_to_transplant = sum(.tmp)
        if(.cells_to_transplant > 0){
          for(.i in 1:.cells_to_transplant){
            .clone_number <- which(.tmp == sample(.tmp, prob = .tmp/sum(.tmp), size = 1))
            .clone_number <- .clone_number[sample(1:length(.clone_number), size = 1)]            
            .ccMatrix@data[.clone_number, .ac + 1] <- .ccMatrix@data[.clone_number, .ac + 1] + 1
            if(ageing == TRUE){
              .ageing_ts <- which(.tmp_ageing[, .clone_number] == sample(.tmp_ageing[, .clone_number], 
                                                              prob = .tmp_ageing[, .clone_number]/sum(.tmp_ageing[, .clone_number]), size = 1))[1]
              .ageing_ts <- .ageing_ts[sample(1:length(.ageing_ts), size = 1)]
              clone_divisions[.ageing_ts, .clone_number] <<- clone_divisions[.ageing_ts, .clone_number] + 1 
              .tmp_ageing[.ageing_ts, .clone_number] <- .tmp_ageing[.ageing_ts, .clone_number] - 1
            }
          }
        }
      }

      ClonalContribution.TimeSeries@tp = ClonalContribution.TimeSeries@tp + 1
      if(sum(.ccMatrix@data[, .t] > 0) == 1 || .t == tsStop)
        break
    }
  }
  #In that case we calculate the solution with lsode
  else{ 
    #definition of the differential equation
    de <- function (t, y, parms){
      ycs = vector(length = nrct + nrcc)
      .N = sum(y)
      .pd = diff_rates(.N)
      .diff = .pd$p - .pd$d
      for(i in 1:(nrct + nrcc)){      
        ycs[i] = y[i] * .diff[i]
      }
      return(list(ycs))
    }
    
    #If we transplant something the differential equation have to be splitted into the different time intervals
    if(nrcc > 0){
      lts = ClonalContribution.TimeSeries@start #Last Timestep
      for(ttp in 1:(length(unique(cancer_ts)) + 1)){ #ttp = transplant time point
        inds = c() #storage for indices if there are more than one
        ct = 0 #the considered transplant timepoint
        if(ttp > length(unique(cancer_ts))) ct = ClonalContribution.TimeSeries@end
        else{
          inds = which(unique(cancer_ts)[ttp] == cancer_ts)
          ct = unique(cancer_ts)[ttp]
        }
        cs = cancer_sizes[inds] #The cancer sizes
        
        y = .ccMatrix@data[,which(ClonalContribution.TimeSeries@series == lts)] #calculation of the start values for the considered time interval
        #calculation for considered time interval
        out = lsode(func = de, y = y, ClonalContribution.TimeSeries@series[which(ClonalContribution.TimeSeries@series == lts):which(ClonalContribution.TimeSeries@series == ct)])

        #write to the output matrix
        .ccMatrix@data[,(which(ClonalContribution.TimeSeries@series == lts)):(which(ClonalContribution.TimeSeries@series == ct))] = t(out)[2:(nrct + nrcc + 1),]
        
        #Transplant in case it is not the last timepoint        
        if(length(inds) > 0) .ccMatrix@data[(nrct+inds[1]):(nrct+inds[length(inds)]), (which(ClonalContribution.TimeSeries@series == ct))] = cs
        
        lts = ct
      } 
    }
    #If there is no transplant we do not have to split the time intervals
    else{
      y = .ccMatrix@data[,1]
      out = lsode(func=de, y=y, ClonalContribution.TimeSeries@series)
      .ccMatrix@data = t(out)[2:(nrct + nrcc + 1),]
    }
  }
  
  return(.ccMatrix)
}
