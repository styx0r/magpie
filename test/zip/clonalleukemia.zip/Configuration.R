######################Parameter######################
config <- read.table("cc.config")

#####Seed#####
set.seed(seed)
##############

#####Time Setup#####
stp = 0 #starting time point
#Stopstrategy ts or MonoClonality (then ts has to be one)
stopStrategy = "ts"
ts = 750 #timesteps (in days)
####################

#######Number of compartments to calculate N for the carying capacity######
nrcomp <- 1
###########################################################################

#####Initial Clone Setup#####
nrct = config[which(config[,1] == "nr_clones"),2] #number of initial different clone types
initdist = "random" #initial distribution of the clones
#possible values: random, equal
minc = 20 #minimal number of clones per type
maxc = 120 #maximum number of clones per type
equc = c(100, 0) #in case it's set to equal this number is taken
#############################

#####Define wether to use a Solver like lsode (differentiated equations) or an approach with a fixes step-width#####
fixed_step = TRUE #Stochasticher Ansatz
####################################################################################################################

#####with or without dice (only in case of fixed_step procedure possible)#####
dice  = TRUE
#in case of false one can use noise
noDiceNoise <- 0.01
#########################################################################

################################Mutation Setup######################################
#Mutation is the change of a cell from one clone to another#
mutation = FALSE
#WARNING: Right now only working for fixed_step=TRUE and dice = TRUE
m_trans_prob <- t(matrix(nrow=nrct, ncol=nrct, data=c(
  0.00, 0.01, #clone 1 to clone 1,2,3,4,5 and 6 (the propability to the clone itself is not considered, so 0 is efficient)
  0.00, 0.00 #clone 2 to clone 1,2,3,4,5 and 6
  )))

####################################################################################

#####Prolif Setup######
prolif = "fixed" #how many cells in one timestep duplicate
#possible values: fixed, eDistributed, nDistributed, nDistributedFixed (Calculated only ince in the beginning)
prolifvf = config[which(config[,1] == "prolif_healthy"),2] #proliferation value fixed
prolifnDistributedSigma = 0.005 #The noise for the normal distribution (means prolifnDistributedSigma * N(clone size))
prolifnDistributedMean = 0.1 #The mean for the normal distribution (means prolifnDistributedMean * N (clone size))
prolifWithLF = TRUE #with logistic function (dumping factor)
prolifCC = 2000 #carrying capacity for logistic function per compartment
#######################

#####Death Setup#####
death = "nDistributedFixed" #how many cells die in one timestep
#possible values: fixed, eDistributed, nDistributed, nDistributedFixed (Calculated only once in the beginning)
deathvf = 0.03 #death value fixed
deathnDistributedSigma = 0.002 #The noise for the normal distribution (means deathnDistributedSigma * N(clone size))
deathnDistributedMean = 0.03 #The mean for the normal distribution (means deathnDistributedMean * N (clone size))
deathWithLF = FALSE #with logistic function (dumping factor)
deathCC = 1000 #carrying capacity for logistic function
#####################

#####Setup for the cancer cells transplantation#####
nrcc = 1 #Number cancer cells transplantations
#Setting the timepoint for the first cancer cell randomly to any between 1 and ts
cancer_ts <<- c(sample(300, size = 1),30,30) #A vector of timesteps, where a cancer cell(s) is put into the system
cancer_sizes = c(1,1,1) #The number of one specific clone putted at one timepoint into the system (length(cancer_sizes) == length(cancer_ts))
cancer_prolifvf = c(config[which(config[,1] == "prolif_cancer"),2],0.14,0.14) #The proliferation rate of the cancer cells, coupled with normal cells for the logistic function (length(cancer_prolif) == length(cancer_ts))
cancer_deathvf = c(0.015,0.05,0.05) #The death rates of the cancer cells, coupled with the normal cells for the logistic function (length(cancer_deathvf) == length(cancer_ts))
cancer_ageing = TRUE #FALSE CASE NOT IMPLEMENTED YET
#####################################################

#####Ageing configuration (with fixed_step only)#####
ageing = FALSE

#a*t + b
ageingprolif = FALSE #Change in the proliferation rates due to the ageing
ageingprolifa = -0.06
ageingprolifb = 0.0

ageingdeath = TRUE #Change in the death rates due to the ageing
ageingdeatha  = 0.035
ageingdeathb = 0.0
################################################

###########Transplant configuration#############################################################
##############Only working with dice, since we need integer values for the transplant###########
serial_transplant = FALSE
serial_transplant_cyclus = 180 #how much time steps after next transplant
serial_noftc = 30 #Number of transplanted cells
######################Don't touch####################
deathDistributionFixedValues = c() #if fixed values for prolif distribution is configured
prolifDistributionFixedValues = c() #if fixed values for prolif distribution is configured

cancer_ts = cancer_ts[1:nrcc] #Only consider the cancer cells according to the number nrcc
cancer_sizes = cancer_sizes[order(cancer_ts)] #Sort the cancer sizes according to the times they are transplanted (smallest to biggest)
cancer_prolifvf = cancer_prolifvf[order(cancer_ts)] #Sort the cancer prolifvf according to the times they are transplanted (smallest to biggest)
cancer_deathvf = cancer_deathvf[order(cancer_ts)] #Sort the cancer deathvf according to the times they are transplanted (smallest to biggest)
cancer_ts = sort(cancer_ts) #Sort the cancer times according to the times they are transplanted (smallest to biggest)

clone_divisions = matrix() #Here the clone divisions are saved as follows in the beginning
#times divisions  0 1
#c_1              5 0
#c_2              5 0
#c_3              5 0
ageingfunprolif = c()
ageingfundeath = c()

#####################################################

