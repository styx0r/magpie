# read solver parametrisation
solver_params <- read.table("solver.config", stringsAsFactors = F)[,2]
names(solver_params) <- read.table("solver.config", stringsAsFactors = F)[,1]

ms <- 1:14
names(ms) <- c("Runge-Kutta",
               "AM1_and_BD1_implicit_euler",
               "AM2_Crank_Nicolson",
               "AM3",
               "AM4",
               "BD2",
               "BD3",
               "BD4",
               "AB1_explicit_euler",
               "AB2",
               "AB3",
               "AB4",
               "Runge-Kutta-Fehlberg",
               "Cash-Karp")

solver_params["m"] <- ms[solver_params["m"]]

system(paste("simulateSBML",
             paste(paste("-", names(solver_params), sep = ""), solver_params, collapse = " "),
             "-o instance.csv",
             "instance.xml"))

in_data <- read.csv("instance.csv")

species <- read.table("species.config")[,2]
names(species) <- read.table("species.config")[,1]
names(species) <- gsub("_initial_concentration", "", gsub("_initial_amount", "", names(species)))

plot_data_species <- data.frame()
for (c in colnames(in_data)[colnames(in_data) != "time"])
  if (c %in% names(species))
    plot_data_species <- rbind(plot_data_species, data.frame(time = in_data["time"], species = c, amount = in_data[,c]))

plot_data_other <- data.frame()
for (c in colnames(in_data)[colnames(in_data) != "time"])
  if ( !(c %in% names(species)) )
    plot_data_other <- rbind(plot_data_other, data.frame(time = in_data["time"], key = c, value = in_data[,c]))

require("ggplot2")
require("RColorBrewer")
man_colors <- brewer.pal(max(length(species),3), "Set1")
if (length(species) > 9)
  man_colors <- colorRampPalette(c("darkblue", "darkblue"))(length(species))
for (s in unique(plot_data_species$species) ) {
  png(paste("species_", s, ".png", sep = ""), width = 2048, height = 1536, res = 300)
    print(ggplot(plot_data_species[plot_data_species$species == s,], aes(time, amount, colour = species)) +
    geom_line() +
    scale_colour_manual(values = man_colors) +
    theme_minimal() +
    ylim(c(min(plot_data_species[plot_data_species$species == s,]$amount),
           max(plot_data_species[plot_data_species$species == s,]$amount) + 
             0.2 * max(plot_data_species[plot_data_species$species == s,]$amount))) +
    theme(text = element_text(size = 16L),
          legend.position = c(1,1),
          legend.justification = c(1,1),
          legend.text = element_text(size = 10L),
          legend.title = element_blank()))
  dev.off()
}

# man_colors <- brewer.pal(max(length(unique(plot_data_other$key)),3), "Set1")
# if(length(unique(plot_data_other$key)) > 9)
#   man_colors <- colorRampPalette(c("white", "darkblue"))(length(unique(plot_data_other$key)))
# for(o in unique(plot_data_other$key)){
#   png(paste("other_", o, ".png", sep = ""), width = 2048, height = 1536, res = 300)
#   print(ggplot(plot_data_other[plot_data_other$key == o,], aes(time, value, colour = key)) +
#     geom_line() +
#     scale_colour_manual(values = man_colors) +
#     theme_minimal() +
#     ylim(c(min(plot_data_other[plot_data_other$key == o,]$value),
#            max(plot_data_other[plot_data_other$key == o,]$value) + 
#              0.2 * max(plot_data_other[plot_data_other$key == o,]$value))) +
#     theme(text = element_text(size = 16L),
#           legend.position = c(1,1),
#           legend.justification = c(1,1),
#           legend.text = element_text(size = 10L),
#           legend.title = element_blank()))
#   dev.off()
# }
