#!/bin/bash
python writeSBMLParameter.py sbml.xml
Rscript startSimulate.R
