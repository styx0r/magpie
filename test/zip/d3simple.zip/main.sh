echo "1\n2\n4\n8\n9" > example.barplot
echo "Successfully created data file for barplot"
