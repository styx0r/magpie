#!/bin/bash
echo “This model just creates the instance config file, based on the configuration files. 
echo "Please click on 'Config' to download the arised config instance files.”;

