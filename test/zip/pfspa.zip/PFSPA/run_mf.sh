#!/bin/bash
./mf -i input.config -s sequence.config
Rscript gridVisualization.R
