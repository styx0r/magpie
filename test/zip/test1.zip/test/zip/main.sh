./helper.sh
echo "Successfully executed helper script"
