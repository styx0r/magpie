from libsbml import *
import sys
import os

if len(sys.argv) < 2:
    print 'Need the sbml model as input parameter.'
    sys.exit()

if not os.path.isfile(sys.argv[1]):
    print 'Is not a valid path to a sbml file.'
    sys.exit()

reader = SBMLReader()

document = reader.readSBML(sys.argv[1])
document.getNumErrors()

model = document.getModel()
parameters = model.parameters
species = model.species
compartments = model.compartments
events = model.events
reactions = model.reactions

# read in config files
in_parameter = {}
with open("parameter.config") as f:
    for line in f:
        if line.lstrip(' ')[0] != "#":
            lsplit = line.lstrip(' ').split()
            in_parameter[lsplit[0]] = lsplit[1]
for e in parameters:
    if in_parameter.has_key(e.id):
        e.setValue(float(in_parameter[e.id]))

in_compartment = {}
with open("compartment.config") as f:
    for line in f:
        if line.lstrip(' ')[0] != "#":
            lsplit = line.lstrip(' ').split()
            in_compartment[lsplit[0]] = lsplit[1]
for e in compartments:
    if in_compartment.has_key(e.id+"_spatial_dimensions"):
        e.setSpatialDimensions(int(float(in_compartment[e.id+"_spatial_dimensions"])))
    if in_compartment.has_key(e.id+"_size"):
        e.setSize(float(in_compartment[e.id+"_size"]))

in_species = {}
with open("species.config") as f:
    for line in f:
        if line.lstrip(' ')[0] != "#":
            lsplit = line.lstrip(' ').split()
            in_species[lsplit[0]] = lsplit[1]
for e in species:
    if in_species.has_key(e.id+"_initial_amount"):
        e.setInitialAmount(float(in_species[e.id+"_initial_amount"]))
    if in_species.has_key(e.id+"_initial_concentration"):
        e.setInitialConcentration(float(in_species[e.id+"_initial_concentration"]))

writeSBMLToFile(document, "instance.xml")
