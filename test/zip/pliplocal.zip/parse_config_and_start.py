import os

class ConfigFile:
    def __init__(self, cfile):
        self.file = cfile
        self.params = {}
        self.parse_config()

    def parse_config(self):
        """Parse config file"""
        with open(self.file, 'r') as f:
            for line in [l for l in f.readlines() if not (l.startswith('#') or len(l.strip())==0)]:
                param, value = line.strip().split(' ')
                if value == 'true':
                    self.params[param] = True
                elif value == 'false':
                    self.params[param] = False
                else:
                    self.params[param] = str(value)


### Read in config

cfg = ConfigFile('default.config.test')

vals = (cfg.params['pdbid'], cfg.params['hydroph_dist_max'], cfg.params['hbond_dist_max'], '-v' if cfg.params['verbose'] else '')
os.system("plip/plipcmd -i %s -xytp --hydroph_dist_max %s --hbond_dist_max %s %s" % vals)

