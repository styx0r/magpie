# Start the main script
python parse_config_and_start.py
