OPENBABEL_LINK="http://downloads.sourceforge.net/project/openbabel/openbabel/2.4.1/openbabel-2.4.1.tar.gz?r=https%3A%2F%2Fsourceforge.net%2Fprojects%2Fopenbabel%2Ffiles%2Fopenbabel%2F2.4.1%2F&ts=1478881669&use_mirror=netix"

mkdir /tmp/babelinstall;
cd /tmp/babelinstall;
wget -O openbabel.tar.gz $OPENBABEL_LINK;
tar zxf openbabel.tar.gz
mkdir build;
cd build;
#Openbabel 2.4.1
BABEL_PATH="../openbabel-2.4.1";
cmake $BABEL_PATH -DPYTHON_BINDINGS=ON;
make;
make install;
export PYTHONPATH=/usr/local/lib:$PYTHONPATH;
